package com.uha.ensisa.webapp.models;

public enum VehicleType {
	CAR,
	BICYCLE,
	BIKE
}
